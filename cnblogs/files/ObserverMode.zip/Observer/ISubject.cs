﻿namespace ConsoleApp2.Observer
{
    internal interface ISubject
    {
        void Add(IObserver obj);
        void Del(IObserver obj);
        void Notify(string msg);
    }
}
