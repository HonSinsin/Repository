﻿using System;

namespace ConsoleApp2.Observer
{
    internal class ContextObserver : IObserver
    {
        public string Name { get; set; } = string.Empty;

        public ContextObserver(string name)
        {
            this.Name = name;
        }

        public void Update(string msg)
        {
            Console.WriteLine($"##> {this.Name} get msg: {msg}");
        }
    }
}
