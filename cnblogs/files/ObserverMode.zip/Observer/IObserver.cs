﻿namespace ConsoleApp2.Observer
{
    internal interface IObserver
    {
        void Update(string msg);
    }
}
