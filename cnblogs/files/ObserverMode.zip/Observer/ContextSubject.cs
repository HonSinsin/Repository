﻿using System.Collections.Generic;

namespace ConsoleApp2.Observer
{
    internal class ContextSubject : ISubject
    {
        List<IObserver> Observers = new List<IObserver>();
        public void Add(IObserver obj)
        {
            Observers.Add(obj);
        }

        public void Del(IObserver obj)
        {
            Observers.Remove(obj);
        }

        public void Notify(string msg)
        {
            foreach (var observer in Observers)
            {
                observer.Update(msg);
            }
        }

        public void ShowMsg(string msg)
        {
            Notify(msg);
        }
    }
}
