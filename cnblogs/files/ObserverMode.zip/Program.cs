﻿using ConsoleApp2.Observer;
using System;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ContextSubject subject = new ContextSubject();

            ContextObserver observer1 = new ContextObserver("user1");
            ContextObserver observer2 = new ContextObserver("user2");

            subject.Add(observer1);
            subject.Add(observer2);
            subject.Notify("test msg 1");

            Console.ReadKey();
        }
    }
}
